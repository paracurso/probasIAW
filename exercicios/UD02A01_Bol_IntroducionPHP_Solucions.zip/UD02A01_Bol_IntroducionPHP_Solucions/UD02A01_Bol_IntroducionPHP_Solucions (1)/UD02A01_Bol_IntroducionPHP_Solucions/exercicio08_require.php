<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Exercicio8-require</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="estilo.css" title="Color">
</head>

<body>
<?php
  	require "exercicio08_texto1.php";
  	require "exercicio08_horario.php";
  	require "exercicio08_texto2.php"
?>
  	
</body>
</html>