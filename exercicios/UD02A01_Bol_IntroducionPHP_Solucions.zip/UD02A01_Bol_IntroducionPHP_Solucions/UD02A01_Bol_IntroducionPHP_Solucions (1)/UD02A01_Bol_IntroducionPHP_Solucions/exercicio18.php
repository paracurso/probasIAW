﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exercicio18</title>
</head>
<body>
    <h1>Exercicio 18</h1>
   <?php
    $num1 = 3;
    $num2 = 7;
    $cociente = $num1 / $num2;
    $resto = $num1 % $num2;
    echo "O cociente de $num1 e $num2 é = $cociente <br>";
    echo "O resto de $num1 e $num2 é = $resto <br>";
    ?>
</body>
</html>