<?php
  	echo "<p>Este módulo impárteses os días: $dias.</p>";
?>