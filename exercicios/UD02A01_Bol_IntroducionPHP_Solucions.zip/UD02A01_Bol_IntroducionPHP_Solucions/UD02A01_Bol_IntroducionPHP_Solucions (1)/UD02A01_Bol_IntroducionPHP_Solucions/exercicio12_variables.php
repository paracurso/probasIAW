<?php
	$modulo = "IAW";
	$horas = 122;
	$dias = "martes. mércores e xoves";
?>