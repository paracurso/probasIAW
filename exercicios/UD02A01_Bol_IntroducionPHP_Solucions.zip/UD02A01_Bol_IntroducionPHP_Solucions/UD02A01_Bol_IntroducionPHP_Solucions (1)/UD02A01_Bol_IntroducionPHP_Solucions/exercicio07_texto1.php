<?php
  	echo "<p>O módulo de IAW ten unha duración total de 122 horas.</p>";
?>