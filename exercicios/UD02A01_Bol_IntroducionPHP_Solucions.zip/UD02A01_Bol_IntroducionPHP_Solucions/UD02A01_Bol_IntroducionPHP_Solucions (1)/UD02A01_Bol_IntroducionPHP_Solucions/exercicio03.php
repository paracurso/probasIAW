  <?php

echo "<!DOCTYPE html>";
echo "<html lang='es'>";
echo "<head>";
echo " <meta charset='utf-8'>";
echo "<title>Exercicio3</title>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<link rel='stylesheet' href='estilo.css' title='Color'>";
echo "</head>";
echo "<body>";
echo "<p>O servidor interpreta correctamente os scripts en php</p>";
echo "</body>";
echo "</html>";

?>

<?php

//Para mostrar ben escrito o código HTML
/*
echo "<!DOCTYPE html>\n";
echo "<html lang='es'>\n";
echo "\t<head>\n";
echo "\t\t<meta charset='utf-8'>\n";
echo "\t\t<title>Exercicio3</title>\n";
echo "\t\t<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n";
echo "\t\t<link rel='stylesheet' href='estilo.css' title='Color'>\n";
echo "\t</head>\n";
echo "\t<body>\n";
echo "\t\t<p>O servidor interpreta correctamente os scripts en php</p>\n";
echo "\t</body>\n";
echo "</html>\n";
*/
?>