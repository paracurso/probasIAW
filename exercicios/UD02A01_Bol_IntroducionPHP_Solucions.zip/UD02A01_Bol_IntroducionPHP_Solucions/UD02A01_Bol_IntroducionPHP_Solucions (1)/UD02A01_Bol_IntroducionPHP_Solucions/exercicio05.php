<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Exercicio5</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="estilo.css" title="Color">
</head>

<body>
  <?php
  	print "<p>O módulo de IAW ten unha duración total de 122 horas.<br/>
  		Este módulo impárteses os días: martes, mércores e xoves.</p>";

	print ("<p>O módulo de IAW ten unha duración total de 122 horas.<br/>
  		Este módulo impárteses os días: martes, mércores e xoves.</p>");
  ?>
</body>
</html>