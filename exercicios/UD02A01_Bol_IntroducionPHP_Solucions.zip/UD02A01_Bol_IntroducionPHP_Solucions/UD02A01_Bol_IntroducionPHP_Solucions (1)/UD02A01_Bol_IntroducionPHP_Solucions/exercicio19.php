﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exercicio19</title>
</head>
<body>
    <h1>Exercicio 19</h1>
   <?php
    $nota1 = 3;
    $nota2 = 7;
    $nota3 = 5;
    $nota4 = 7;
    $media = ($nota1 + $nota2 + $nota3 + $nota4) / 4;
    $dni = "12345678-B";
    echo "o alumno con DNI: $dni ten unha media de $media";
    ?>
</body>
</html>