<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Exercicio15</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="estilo.css" title="Color">
</head>

<body>
<?php
    const CONSB = false;
    const CONSF = 4.5;

    define ("CONSE", 70);
    define ("CONSC", "Esta é a constante de cadea");

    echo "A constante booleana ten valor: ".CONSB.' <br/>';
    echo "A constante de tipo float ten valor: ".CONSF.' <br/>';
    echo "A constante de tipo enteiro ten valor: ".CONSE.' <br/>';
    echo "A constante de tipo cadea ten valor: ".CONSC.' <br/>';
?>
</body>
</html>