<?php
  	echo "<p>Este módulo impárteses os días: martes, mércores e xoves.</p>";
?>