﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exercicio30</title>
</head>
<body>
    <h1>Exercicio 30</h1>
   <?php
    
    $num = 4;
        
    echo "Dado un número N = $num, a suma dos N primeiros números é: ".($num * ($num + 1) / 2);
    ?>
</body>
</html>