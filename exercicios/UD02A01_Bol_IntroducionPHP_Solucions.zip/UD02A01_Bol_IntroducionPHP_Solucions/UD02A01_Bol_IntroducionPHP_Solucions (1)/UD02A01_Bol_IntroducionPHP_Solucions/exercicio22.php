﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exercicio22</title>
</head>
<body>
    <h1>Exercicio 22</h1>
   <?php
    $horas = 2;
    $min = $horas * 60;
    $seg = $horas * 60 * 60;
    echo "$horas horas son $min minutos <br>";
    echo "$horas horas son $seg segundos";
    ?>
</body>
</html>