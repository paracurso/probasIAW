﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exercicio17</title>
</head>
<body>
    <h1>Exercicio 17</h1>
   <?php
    $num1 = 3;
    $num2 = 7;
    $suma = $num1 + $num2;
    echo "A suma de $num1 e $num2 é = $suma";
    ?>
</body>
</html>