<?php
  	echo "<p>O módulo de $modulo ten unha duración total de $horas horas.</p>";
?>