﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exercicio21</title>
</head>
<body>
    <h1>Exercicio 21</h1>
   <?php
    $a = 3;
    $n = 5;
    echo "O resultado de calcular a expresión a<sup>n</sup> é ".$a**$n;
    echo "<br> Outra forma de calcular a expresión é coa función pow => ".pow($a, $n);
    ?>
</body>
</html>