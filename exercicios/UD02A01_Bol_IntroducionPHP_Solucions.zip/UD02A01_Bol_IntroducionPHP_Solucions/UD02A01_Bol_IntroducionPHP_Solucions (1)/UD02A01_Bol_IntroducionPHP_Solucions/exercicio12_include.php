<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Exercicio12-include</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="estilo.css" title="Color">
</head>

<body>
<?php
	//O include inclúe o ficheiro, se este non existe só amosa un aviso
	include "exercicio12_variables.php";
	include "exercicio12_texto1.php";
	include "exercicio12_horario.php";
	include "exercicio12_texto2.php"
?>
  	
</body>
</html>